'use strict';
function createTracker({ site }) {
  const counts = {};
  let events = 0;
  return {
    track(event, props = {}) {
      counts[event] = (counts[event] || 0) + 1;
      events++;
      return { site, event, props, at: Date.now() };
    },
    stats() {
      return { site, events, counts: { ...counts } };
    },
  };
}
module.exports = { createTracker };
