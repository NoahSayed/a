'use strict';
const fs = require('node:fs');

function createNoteStore({ file }) {
  const load = () => { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return {}; } };
  const save = (d) => fs.writeFileSync(file, JSON.stringify(d, null, 2));
  return {
    get(orderId) {
      return load()[String(orderId)] || null;
    },
    set(orderId, text, opts = {}) {
      const data = load();
      const key = String(orderId);
      const cur = data[key];
      if (cur && opts.userId && cur.owner !== opts.userId) {
        throw Object.assign(new Error('not your order'), { status: 403 });
      }
      data[key] = { text, owner: cur ? cur.owner : opts.userId || null };
      save(data);
      return data[key];
    },
  };
}

module.exports = { createNoteStore };
