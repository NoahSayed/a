# @bakery/order-notes

> **ABANDONED.** No longer maintained since 2022. No new releases will be published.

Tiny JSON-file store for per-order notes. `set(orderId, text, { userId })` records who wrote the note and, when
`userId` is given, only lets the order's owner change it.
